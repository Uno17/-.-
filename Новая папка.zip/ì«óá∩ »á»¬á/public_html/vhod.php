<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="keywords" content="" />
<meta name="description" content="Электронный учебник по Информатике" />
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Главная - Информатика</title>
<link href="style.css" rel="stylesheet" type="text/css" media="screen" />
<script type="text/javascript" src="jwplayer/jwplayer.js"></script>
<meta name="generator" content="TurboSite 1.7.1" />
 <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">


</head>

<body>
<div id="wrapper">
	<div id="header">
		<div id="logo">
			<h1><a href="vhod.php">Информатика</a></h1>
			<p>5 класс</p>
		</div>
	</div>
	<!-- end #header -->
    <div id="menu">
		<ul>
			<li class="active"><a style="" href="">Главная</a></li>
			<li class="active"><a style="" href="">Практикум</a></li>

		</ul>
	</div>
	<!-- end #menu -->
<!--Forma-->
<div class="conteiner text-center">
<h1>Форма входа</h1>
<form class="row justify-content-md-center" method="post" action="reg.html">
    
    <div class="mb-3 col-12 col-md-4">
        <label for="formGroupExampleInput" class="form-label">Логин</label>
        <input type="text" class="form-control" id="formGroupExampleInput" placeholder="Введите логин">
      </div>
    <div class="mb-3 col-12 col-md-4">
      <label for="exampleInputPassword1" class="form-label">Пароль</label>
      <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Введите пароль">
    </div>
    <div class="w-100"></div>
    <button type="button" class="btn btn-primary">Войти</button>
    <a href="reg.php">Регистрации</a>
  </form>
</div>
<!--end forma-->

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </body>
</html>
<!--end forma-->
