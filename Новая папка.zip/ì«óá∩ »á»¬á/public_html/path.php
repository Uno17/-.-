<?php

define('BASE_URL', 'http://localhost/%d0%9d%d0%be%d0%b2%d0%b0%d1%8f%20%d0%bf%d0%b0%d0%bf%d0%ba%d0%b0/public_html/index.html');