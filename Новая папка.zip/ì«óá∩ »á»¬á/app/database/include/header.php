<head>
<meta name="keywords" content="" />
<meta name="description" content="Электронный учебник по Информатике" />
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Главная - Информатика</title>
<link href="style.css" rel="stylesheet" type="text/css" media="screen" />
<script type="text/javascript" src="jwplayer/jwplayer.js"></script>
<meta name="generator" content="TurboSite 1.7.1" />

</head>