<?php

$driver = 'mysql';
$host = 'localhost';
$data = 'электронный_учебник';
$user = 'root';
$pass = 'mysql';
$charset = 'utf8';
$options = [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION];

try{
    $pdo = new PDO(
        "$driver:host=$host; data=$data; charset=$charset", $user, $pass, $options
    );
}catch (PDOException $i){
    die("Ошибка подключения к бд"); 
}
?>