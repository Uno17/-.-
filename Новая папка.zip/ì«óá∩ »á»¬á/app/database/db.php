<?php 

require('connect.php');

function tt($value){
    echo '<pre>';
        print_r($value);
    echo '</pre>';
}

$sql = 'SELECT * FROM users';
$query = $pdo->prepare($sql);
$errInfo = $query->errorInfo();
if ($errInfo[0] !== PDO::ERR_NONE){
    echo $errInfo[2];
    exit();
}
$date = $query->fetchALL();
tt($date); 